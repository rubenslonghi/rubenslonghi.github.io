# Confronto con gli appunti della 1 SP

Sono indicizzate 76 immagini. La collocazione indica il percorso corrispondente, non una trascrizione diplomatica di ogni riga.

| Fonte | Collocazione |
|---|---|
| 02_10 - Dalle parole alle espressioni-1.jpg | Capitolo1.NZ.tex |
| 05_11 - Il prodotto cartesiano-1.jpg | InsiemiLogica.tex |
| 05_11 - Il prodotto cartesiano-2.jpg | InsiemiLogica.tex |
| 05_11 - Problemi con insiemi-1.jpg | InsiemiLogica.tex |
| 06_11 - Proprietà delle operazioni tra insiemi-1.jpg | InsiemiLogica.tex |
| 06_11 - Proprietà delle operazioni tra insiemi-2.jpg | InsiemiLogica.tex |
| 07_11 - esercizi sugli insiemi-1.jpg | rimandi al manuale |
| 08_10 - Aritmetica modulare-1.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - Aritmetica modulare-2.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - Aritmetica modulare-3.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - Aritmetica modulare-4.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - Aritmetica modulare-5.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - I numeri interi-1.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - I numeri interi-2.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - I numeri interi-3.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 08_10 - I numeri interi-4.jpg | integrazione-numeri.tex; appunti-interi.tex |
| 09_10 - Le operazioni fra interi-1.jpg | appunti-interi.tex |
| 09_10 - Le operazioni fra interi-2.jpg | appunti-interi.tex |
| 09_10 - Le operazioni fra interi-3.jpg | appunti-interi.tex |
| 15_10 - Le frazioni e i numeri razionali-1.jpg | Razionali.tex; appunti-razionali.tex |
| 15_10 - Le frazioni e i numeri razionali-2.jpg | Razionali.tex; appunti-razionali.tex |
| 15_10 - Le frazioni e i numeri razionali-3.jpg | Razionali.tex; appunti-razionali.tex |
| 15_10 - Le frazioni e i numeri razionali-4.jpg | Razionali.tex; appunti-razionali.tex |
| 15_10 - Le frazioni e i numeri razionali-5.jpg | Razionali.tex; appunti-razionali.tex |
| 16_10 - Espressioni con numeri razionali-1.jpg | Razionali.tex; appunti-razionali.tex |
| 16_10 - Espressioni con numeri razionali-2.jpg | Razionali.tex; appunti-razionali.tex |
| 16_10 - Espressioni con numeri razionali-3.jpg | Razionali.tex; appunti-razionali.tex |
| 17_09 - Introduzione ai naturali-1.jpg | Capitolo1.NZ.tex |
| 17_09 - Introduzione ai naturali-2.jpg | Capitolo1.NZ.tex |
| 19_09 - Le quattro operazioni in N-1.jpg | Capitolo1.NZ.tex |
| 19_10 - Espressioni e problemi con i numeri razionali e percentuali-1.jpg | Razionali.tex; zq-simulazione-classe.pdf |
| 19_10 - Espressioni e problemi con i numeri razionali e percentuali-2.jpg | Razionali.tex; zq-simulazione-classe.pdf |
| 19_10 - Espressioni e problemi con i numeri razionali e percentuali-3.jpg | Razionali.tex; zq-simulazione-classe.pdf |
| 19_10 - Espressioni e problemi con i numeri razionali e percentuali-4.jpg | Razionali.tex; zq-simulazione-classe.pdf |
| 20_11 - Relazioni e funzioni-1.jpg | appunti-relazioni.tex; Grafi.tex |
| 20_11 - Relazioni e funzioni-2.jpg | appunti-relazioni.tex; Grafi.tex |
| 20_11 - Relazioni e funzioni-3.jpg | appunti-relazioni.tex; Grafi.tex |
| 20_11 - Relazioni e funzioni-4.jpg | appunti-relazioni.tex; Grafi.tex |
| 20_11 - Relazioni e funzioni-5.jpg | appunti-relazioni.tex; Grafi.tex |
| 21_09, 24_09 - Proprietà delle operazioni-1.jpg | Capitolo1.NZ.tex |
| 21_09, 24_09 - Proprietà delle operazioni-2.jpg | Capitolo1.NZ.tex |
| 21_09, 24_09 - Proprietà delle operazioni-3.jpg | Capitolo1.NZ.tex |
| 22_10 - Esercizi di riepilogo-1.jpg | appunti-razionali.tex |
| 24_09 - La geometria delle operazioni-1.jpg | Capitolo1.NZ.tex |
| 24_09 - La geometria delle operazioni-2.jpg | Capitolo1.NZ.tex |
| 24_10 - Curiosità sui razionali, Achille e la tartaruga-1.jpg | Razionali.tex |
| 25_09 - Le potenze, multipli, divisori, numeri primi-1.jpg | Capitolo1.NZ.tex |
| 26_09 - Multipli e divisori, numeri primi-1.jpg | Capitolo1.NZ.tex |
| 26_09 - Multipli e divisori, numeri primi-2.jpg | Capitolo1.NZ.tex |
| 26_09 - Multipli e divisori, numeri primi-3.jpg | Capitolo1.NZ.tex |
| 26_10 - I numeri irrazionali e l'insieme R-1.jpg | appunti-reali.tex |
| 26_10 - I numeri irrazionali e l'insieme R-2.jpg | appunti-reali.tex |
| 26_10 - I numeri irrazionali e l'insieme R-3.jpg | appunti-reali.tex |
| 26_10 - I numeri irrazionali e l'insieme R-4.jpg | appunti-reali.tex |
| 26_10 - I numeri irrazionali e l'insieme R-5.jpg | appunti-reali.tex |
| 28_09 - MCD, mcm-1.jpg | Capitolo1.NZ.tex |
| 28_09 - MCD, mcm-2.jpg | Capitolo1.NZ.tex |
| 28_09 - MCD, mcm-3.jpg | Capitolo1.NZ.tex |
| 29_10 - Gli insiemi-1.jpg | InsiemiLogica.tex |
| 29_10 - Gli insiemi-2.jpg | InsiemiLogica.tex |
| 29_10 - Gli insiemi-3.jpg | InsiemiLogica.tex |
| 30_11 - Definizioni insiemi-1.jpg | InsiemiLogica.tex |
| 30_11 - Definizioni insiemi-2.jpg | InsiemiLogica.tex |
| 30_11 - Definizioni insiemi-3.jpg | InsiemiLogica.tex |
| 30_11 - Definizioni insiemi-4.jpg | InsiemiLogica.tex |
| Approfondimenti-1.jpg | integrazione-numeri.tex; Razionali.tex |
| Approfondimenti-2.jpg | integrazione-numeri.tex; Razionali.tex |
| Compito per il 19_09-1.jpg | Capitolo1.NZ.tex |
| Gli insiemi numerici N, Z, Q, R-1.jpg | Capitolo1.NZ.tex |
| Gli insiemi-1.jpg | pagina titolo senza contenuti |
| Logica-1.jpg | InsiemiLogica.tex |
| Logica-2.jpg | InsiemiLogica.tex |
| Logica-3.jpg | InsiemiLogica.tex |
| Logica-4.jpg | InsiemiLogica.tex |
| Logica-5.jpg | InsiemiLogica.tex |
| Logica-6.jpg | InsiemiLogica.tex |

I soli rimandi al manuale (per esempio 7 novembre: 92, 93, 102, 103, 121–124) non contengono il testo degli esercizi. Le pagine vuote non sono riprodotte. Titolo 30/11 e data interna 30 ottobre discordano.
