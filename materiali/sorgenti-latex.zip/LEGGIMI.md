# Libro di matematica — aggiornamento del 25 novembre 2026

Il progetto comprende il percorso della 1 SP e i materiali della 2BS recuperati dalle conversazioni e dai file locali. Per la 1 SP, gli appunti esportati il 21 novembre hanno precedenza per dati, esempi e notazione. Le figure nuove sono in TikZ; gli approfondimenti distinti già presenti sono conservati.

Aprire questa cartella nell'editor LaTeX e scegliere **libro.tex** come documento principale. Il progetto è composto da più file: occorre conservare insieme `capitoli`, `figure` e `materiali`. La compilazione del libro usa i PDF dei fascicoli già preparati.

- `libro.tex`: edizione studente.
- `libro-docente.tex`: stesso libro con soluzioni e fascicoli docente; richiama il documento principale senza duplicarlo.
- `libro.pdf` e `libro-docente.pdf`: copie di consegna.
- `CONFRONTO-APPUNTI.md`: indice delle 76 immagini e collocazione dei contenuti.
- `capitoli/registro-integrazione.tex`: provenienza, correzioni e limiti del recupero delle conversazioni.
- `materiali/digitali`: fogli di calcolo, attività e quiz modificabili.

Compilazione locale: `latexmk -pdf libro.tex` oppure `latexmk -pdf libro-docente.tex`. È possibile usare l'editor integrato con l'intero progetto. Titolo e autore sono ancora i campi modificabili del modello originale.

Attività ed esercizi mantengono i riquadri presenti nel progetto ricevuto; esempi e dimostrazioni hanno titoletti. Il registro precisa quali parti sono lezioni, proposte o recuperi. Alcuni allegati finali delle vecchie chat non sono stati recuperati: non vengono presentati come se fossero stati consultati integralmente.

## Modificare il testo

I capitoli sono nella cartella `capitoli`, i disegni nella cartella `figure`. Modificare i file inclusi e ricompilare il documento principale. Per gli ambienti numerati usare due argomenti: `\begin{esercizio}{Titolo}{chiave-univoca}` e la corrispondente chiusura. L'ambiente `soluzione` compare soltanto nell'edizione docente.

Le opzioni di stampa e i colori sono definiti in `libro.tex`. I fascicoli autonomi sono allegati al capitolo pertinente; per sostituirne uno mantenere il nome atteso nella cartella `materiali`.

La cartella privata di ricognizione conserva le tracce di lavoro e le copie di sicurezza. Non fa parte dell'archivio dei sorgenti di consegna, che contiene solo progetto, materiali didattici e registri editoriali.
