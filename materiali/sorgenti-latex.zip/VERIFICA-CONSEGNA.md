# Verifica della consegna del 25 novembre 2026

Entrambe le edizioni compilate con latexmk/pdfLaTeX: nessun errore, riferimento indefinito, carattere mancante o contenuto fuori dai margini segnalato nei log finali. Controllati la presenza delle dipendenze, la distinzione delle soluzioni tra le edizioni e i contenuti essenziali dei capitoli nuovi.

Revisione visiva delle pagine tramite anteprime di entrambe le edizioni; ingrandimenti per diagonale del quadrato, spirale di Teodoro, diagrammi e intersezioni, notazione, relazioni e impaginazione delle soluzioni. Conservati gli spazi di lavoro dei fascicoli e la loro numerazione interna.

- Edizione studente: 222 pagine.
- Edizione docente: 295 pagine.

I controlli editoriali non sostituiscono una nuova soluzione indipendente di ciascun esercizio dei fascicoli preesistenti. Fonti incomplete e allegati cloud mancanti sono elencati in REGISTRO-CONSEGNA.md e nel registro finale del libro.
