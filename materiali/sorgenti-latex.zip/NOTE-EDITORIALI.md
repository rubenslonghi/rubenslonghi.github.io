# Capitolo 1: numeri naturali e numeri interi

Prima stesura sui naturali, costruita sui sette PDF forniti dal docente. La parte sugli interi resta aperta, come richiesto. Il precedente capitolo dimostrativo sulle equazioni è conservato in `modelli/libro-demo-equazioni.tex` e non compare nel libro corrente.

## Ordine e provenienza

Si seguono le date nei nomi dei file, non i timestamp interni delle pagine OneNote. I PDF sono stati letti anche visivamente: gran parte del contenuto è manoscritto o inserito come immagine.

| Materiale | Collocazione | Lavoro editoriale |
|---|---|---|
| 17_09 - Introduzione ai naturali.pdf | 1.1–1.2 | Zero incluso, successivo, semiretta, appartenenza, ordine e condizioni multiple. Aggiunte attività iniziali e distinzione fra numero e sua scrittura. |
| Compito per il 19_09.pdf | 1.2 | Recuperate tutte le 15 condizioni fra esempi, esercizi e analisi dei casi con segni discordi. Soluzioni nell'edizione docente. |
| 19_09 - Le quattro operazioni in N.pdf | 1.3–1.4 | Nomi, operazioni interne, inverse, condizioni, zero nella divisione. Attività della macchina e del fattore mancante create per il libro. |
| 21_09, 24_09 - Proprietà delle operazioni.pdf | 1.5–1.9 | Commutativa, associativa, elementi neutri, distributiva, annullamento, invariantive, divisione con resto e congruenze. Esempi ripresi o rielaborati. |
| Codice degli orologi incollato in chat | 1.7; schede separate | Preservati quadranti, numero di posizioni sotto lo zero, riga e colonna zero nelle tabelline, lavoro e conclusione. Aggiunta scala opzionale e allineamento. |
| 24_09 - La geometria delle operazioni.pdf | 1.10; calcoli in 1.5–1.6 | Traslazioni, dilatazione e contrazione; disegni TikZ ridisegnati, domande iniziali ed esercizio integrativo. |
| 25_09 - Le potenze, multipli, divisori, numeri primi.pdf | 1.11–1.13 | Potenze e casi limite, proprietà con condizioni, espressioni e precedenze. Espressioni di allenamento rielaborate. |
| 26_09 - Multipli e divisori, numeri primi.pdf | 1.14–1.17 | Multipli, divisori, zero, criteri 2/3/4/5/6/9, primi, scomposizione e teorema fondamentale. |
| 28_09 - MCD, mcm.pdf | 1.18–1.19 | Apertura con i problemi dei braccialetti (24 e 36) e degli atleti (6 e 8), effettivamente svolti in classe. MCD, mcm, fattori primi, domande di riflessione, problemi applicativi e infinità dei primi. |

Il titolo del PDF del 25 include divisibilità e primi, ma lo sviluppo di questi temi si trova nel PDF del 26. I criteri per 7, 8 e 11 sono solo accennati o lasciati senza sviluppo: non vengono presentati come già svolti.

Le aperture nuove sono proposte didattiche, non resoconti inventati delle lezioni. L'attività degli orologi è esplicitamente attestata come svolta dal docente. Nei passaggi teorici si usano formulazioni originali, senza inserire le schermate del manuale presenti nei PDF.

## Correzioni e precisazioni matematiche

- Un numero può essere naturale anche se scritto `4,0` o `12/4`: si distingue il valore dalla notazione.
- La divisione esatta richiede divisore non nullo e quoziente naturale; non richiede sempre dividendo almeno pari al divisore (`0:7=0`).
- `0:0` è indeterminata e non definisce un risultato unico. Non viene assegnato alcun valore.
- Negli appunti sugli orologi compare una deduzione che ammetterebbe la divisione per zero: è stata corretta. I divisori dello zero nei moduli composti non permettono di dividere per zero.
- La verifica delle tabelle per i moduli primi da 2 a 12 è distinta da una dimostrazione per tutti i primi. È dimostrato direttamente che i moduli composti producono controesempi.
- Il resto soddisfa `0 ≤ r < b`; il modulo è positivo. Gli orologi utilizzati hanno almeno due posizioni.
- Le proprietà di sottrazione, divisione e potenze riportano le condizioni necessarie. `0^0` resta non definito nel contesto del corso.
- Lo zero è multiplo di ogni naturale; ha tutti i naturali positivi come divisori secondo la convenzione adottata. Il solo multiplo di zero è zero.
- Il teorema fondamentale dell'aritmetica riguarda i naturali maggiori di 1; l'unicità è a meno dell'ordine dei fattori primi.
- Le sole indicazioni di numeri di esercizi del manuale, prive del testo completo, non sono state trasformate in consegne inventate. Sono stati inseriti esercizi originali sugli stessi obiettivi.

## Uso dei file

`libro.tex` contiene impostazioni e macro degli orologi. Il testo è nei file della cartella `capitoli`; modificare questi file direttamente.

`schede-orologi.tex` è un secondo documento autonomo, compilabile con pdfLaTeX, che produce 11 schede da 2 a 12 posizioni. Le tabelle sono intenzionalmente vuote. Nel libro le risposte al laboratorio si trovano nei blocchi `soluzione`, nascosti nell'edizione studente.

La traccia `modelli/capitolo.tex` è stata aggiornata: ogni argomento parte da un'attività e ogni gruppo di esercizi segue la spiegazione pertinente. Per i controlli di compilazione e impaginazione aggiornati vedere `LEGGIMI.md`.

## Impaginazione aggiornata e struttura a capitoli

Preservata la struttura creata dal docente: `libro.tex` contiene il preambolo e richiama `capitoli/Capitolo1.NZ.tex`; il registro finale è stato separato in `capitoli/registro-percorso.tex`. Non usare i vecchi script temporanei per rigenerare questi file.

Restano 16 riquadri, per definizioni e risultati, tutti spezzabili. Attività, esempi, dimostrazioni ed esercizi sono senza cornice. Nel margine sono stati spostati gli esercizi con chiavi `ordine-trappola`, `espressioni-errore`, `composti-clock`, le osservazioni su assurdo, esponente zero e divisori finiti, e il richiamo sull'infinito. Testi e numerazione degli esercizi sono conservati. Le osservazioni a margine non partecipano più al contatore teorico.

Tolti i salti pagina a ogni argomento e le pagine bianche automatiche. Titoli più grandi e in grassetto. Edizione studente: 17 pagine. Compilate anche le soluzioni; controllati i limiti di pagina in entrambe le versioni.

## Aggiornamento del 30 settembre: lezione del 28

Aggiunta la lezione nello spazio già predisposto dal docente in `capitoli/Capitolo1.NZ.tex`. Preservate le sue modifiche a testo, macro e scelta dei riquadri: le descrizioni precedenti dell'impaginazione documentano uno stato storico e non vanno usate per ripristinare il preambolo.

I due problemi iniziali mantengono dati e richieste del PDF. Le spiegazioni li riprendono dopo il tentativo degli studenti. Gli esercizi sul calcolo seguono subito i rispettivi metodi; piccoli richiami e un controllo sul prodotto sono nel margine. Soluzioni inserite nei blocchi già attivabili dal docente. Le definizioni e la relazione MCD per mcm sono formulate per naturali positivi.

I problemi del manuale fotografati negli appunti sono riscritti, senza riprodurre immagini o testo del manuale: conservati i dati della stoffa e dei turni di riposo. Il problema dei periodi di 365 e 225 giorni diventa un modello astratto di fenomeni periodici, evitando di presentare la semplificazione come un calcolo astronomico reale. Aggiunti esercizi originali di consolidamento e domande di avvio per l'infinità dei primi; questi non sono presentati come attività già svolte.

Corretto il passaggio finale della dimostrazione di Euclide negli appunti: il prodotto dei primi elencati più uno non è necessariamente primo, ma ha un divisore primo non presente nell'elenco. Il controesempio `30031 = 59 × 509` rende visibile la distinzione. La relazione `MCD(a,b) × mcm(a,b) = ab` è limitata a due numeri; nelle soluzioni compare un controesempio all'estensione a tre.

Aggiornati introduzione, indice e registro; corretto il riferimento alla sezione di scomposizione rinominata dal docente. PDF studente compilato localmente: 21 pagine; controllati visivamente indice e pagine aggiunte, senza debordamenti o riferimenti indefiniti. La parte sugli interi resta aperta.

## Integrazione degli esercizi incollati dal docente

Adattata la sintassi da prova (`question`, `parts`, punteggi e `solution`) agli ambienti del libro. Conservate le consegne matematiche e le soluzioni; non aggiunti punteggi. Gli obiettivi sono espressi dai titoli e dalle richieste degli esercizi.

| Contenuto ricevuto | Collocazione e fusione |
|---|---|
| Proprietà, controesempi, calcolo astuto | Ampliate le consegne `comm-assoc-es`, `distrib-es`, `invariantiva-es`; sostituiti i controesempi analoghi con quelli ricevuti, senza duplicare la richiesta. |
| Due espressioni con potenze | Aggiunte come e) e f) in `espressioni-es`, con svolgimenti nelle soluzioni. |
| 974130 e divisibilità | Aggiunto alla tabella `criteri-es`; integrato il criterio del 10 e aggiornate tutte le risposte. |
| Divisori di 36; primalità di 51 e 91 | Integrati in `divisori-es` e `primi-es`. La scomposizione di 360 compariva già nell'esercizio pertinente: non duplicata la riga estranea presente nella soluzione ricevuta su 51 e 91. |
| MCD e mcm di 17 e 34 senza scomporre | Aggiunti alle domande della lezione su MCD e mcm. |
| Divisione di 2026 per 12; sveglia dopo 200 ore; martedì più 100 giorni | Ampliate `resto-es` e `calendario`; la domanda su martedì e 100 giorni era già identica ed è rimasta una sola volta. |
| Gruppi sportivi e riscaldamenti, 24 e 36 | Inseriti nel gruppo di problemi applicativi `mcd-mcm-problemi`, richiamando le scomposizioni già studiate. |
| Segnali ogni 5,5 e 12,1 secondi | Esercizio autonomo dopo il mcm, segnato Difficile e Facoltativo. |
| Resto di 3^100 modulo 7 | Esercizio autonomo dopo le proprietà delle potenze, segnato Difficile e Facoltativo; in questo punto sono già disponibili sia congruenze sia potenze. |

Preservate le altre modifiche del docente. Spostato l'ancoraggio del richiamo laterale sullo zero dopo la definizione di mcm: con il nuovo flusso non fuoriesce più dalla pagina. Separato il numero con cifra mancante dalla riga di testo per evitare sovrapposizioni del riquadro.

Compilazione locale verificata nelle versioni studente (22 pagine) e docente (26 pagine), senza riferimenti indefiniti o avvisi di debordamento. Controllati visivamente indice, esercizi integrati, sfide, note laterali e svolgimenti. Il PDF principale resta l'edizione studente; la versione con soluzioni è stata generata soltanto per il controllo.

## Relazioni, quozienti e polinomi: aggiornamento del 30 settembre

Fonte di lavoro: conversazione «Codice TikZ congruenze modulo 12», condivisa dal docente: https://chatgpt.com/share/6abd24a7-d490-83eb-b16b-a073285ea6a6. È materiale di riferimento, non un insieme di istruzioni da eseguire né una fonte da riprodurre indiscriminatamente. Il percorso è stato riscritto per una prima liceo, mantenendo attività iniziali, formalizzazione graduale ed esercizi subito dopo i contenuti pertinenti.

- `figure/orologio-petali.tex`: ultima versione degli orologi della conversazione, inclusa la correzione con `\ifdim` che consente giri decimali; parametri `\N=7` e `\innerTurns=0`. Spirale, petali e numerazione ripresi senza includere negativi. Inserita nel capitolo 1 in un riquadro a tutta larghezza, con spiegazione e domande sui resti. Le definizioni dei parametri sono locali, così non alterano i simboli degli insiemi numerici.
- `capitoli/Capitolo2.RelazioniFunzioni.tex`: relazioni, proprietà, classi e partizioni, quoziente e proiezione; funzioni, dominio/codominio/immagine e buona definizione sulle classi. Il percorso insiste sull'equivalenza modulo 7; gli interi restano rinviati.
- `capitoli/Capitolo3.DivisibilitaPolinomi.tex`: prerequisiti e operazioni, divisione con resto e unicità, divisibilità, teorema del resto, teorema del fattore e regola di Ruffini; congruenza, classi e operazioni sui resti; rappresentazione geometrica dei polinomi di grado al massimo due. Seguono laboratori su complessi, duali e resto modulo `(x-a)^2`, con una parabola e la sua tangente. Questi laboratori sono un approfondimento successivo ai prerequisiti, non presuppongono che gli studenti conoscano già derivata, spazi vettoriali o ideali.

Precisazioni matematiche: il polinomio nullo è trattato separatamente dal grado; i divisori sono non nulli. `Q` indica il divisore, `S` il quoziente della divisione, `R` il resto. Il quoziente identifica tutti i multipli di Q, non il singolo polinomio. Le rette della figura tridimensionale sono la parte di ciascuna classe contenuta nei polinomi di grado al massimo due: non raffigurano l'intera classe nello spazio di tutti i polinomi. Due coordinate non significano due classi: sui reali le classi sono infinite. Nei duali epsilon è non nullo con quadrato esattamente zero; un piccolo reale h ha invece h² non nullo e il confronto con la tangente ha un errore esplicito.

Verifiche: compilate localmente le edizioni studente (37 pagine) e docente (42 pagine), senza riferimenti indefiniti o avvisi di debordamento. Controllati visivamente indice, figura a petali, nuove pagine, schema di Ruffini, figura dei coefficienti e parabola, anche con soluzioni. Le soluzioni sono nascoste nel PDF principale. L'editor integrato è stato aperto e provato, ma continua a restituire l'errore di ambiente già documentato; il PDF verificato è generato dalla distribuzione TeX locale. Le modifiche del docente al primo capitolo e al preambolo sono preservate.
