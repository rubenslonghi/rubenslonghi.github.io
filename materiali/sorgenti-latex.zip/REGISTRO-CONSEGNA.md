# Registro della consegna

Sono stati integrati i materiali pertinenti alla 1 SP e alla 2BS recuperabili dalle conversazioni dal 30 settembre e dai file locali. Per la 1 SP è stato svolto un confronto con le 76 immagini dell'esportazione del 21 novembre: vedere CONFRONTO-APPUNTI.md.

Le conversazioni Chat talvolta restituiscono solo gli ultimi cinque scambi: il recupero non certifica la lettura della loro intera storia. Restano mancanti i file finali cloud della verifica di insiemi e logica (varianti 45/60 minuti e versione schematica) e del quiz generale di 75 quesiti algebrici. Il quiz di 44 disequazioni è invece incluso integralmente. Non sono incluse assegnazioni nominative o valutazioni individuali degli studenti.

I fascicoli sono inseriti accanto ai rispettivi argomenti, mantenendo la numerazione originale interna. Gli esercizi autonomi nascondono le soluzioni nell'edizione studente. Esempi e diagrammi già svolti in classe restano spiegati anche per gli studenti.

Le correzioni matematiche sono riepilogate nel registro in fondo al libro. Le pagine che mostrano solo riferimenti al manuale non consentono di ricostruire il testo degli esercizi. Le date discordanti degli appunti restano segnalate.
